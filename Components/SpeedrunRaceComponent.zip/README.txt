===========================================================
       SPEEDRUN RACE TRACKER — ИНСТРУКЦИЯ ПО УСТАНОВКЕ
===========================================================

1. УСТАНОВКА В LIVESPLIT
-----------------------------------------------------------
- Распакуйте содержимое этого архива в папку компонентов LiveSplit (LiveSplit\Components).
- Откройте LiveSplit.
- Нажмите правой кнопкой мыши по области таймера -> Edit Layout.
- Нажмите кнопку "+ Add" -> Component.
- В списке компонентов выберите "SpeedRun Race Tracker".
- Нажмите OK.

2. РЕГИСТРАЦИЯ
-----------------------------------------------------------
- Перейдите на сайт: https://aut0mat1clol.github.io/SpeedrunRacing
- Создайте аккаунт (логин и пароль).

3. НАСТРОЙКА КОМПОНЕНТА
-----------------------------------------------------------
- В окне "Edit Layout" нажмите правой кнопкой мыши по 
  добавленному компоненту SpeedRun Race Tracker -> Edit.
- Введите ваш логин и пароль, которые вы использовали 
  при регистрации на сайте.
- Нажмите OK.

4. ПОДКЛЮЧЕНИЕ К ГОНКЕ
-----------------------------------------------------------
- Получите ID гонки у организатора или найдите её на сайте.
- Введите ID гонки в настройках компонента LiveSplit.
- Нажмите "Подключиться" (Connect).

Теперь ваше время будет передаваться в реальном времени!
===========================================================

===========================================================
       SPEEDRUN RACE TRACKER — INSTALLATION GUIDE
===========================================================

1. INSTALLATION IN LIVESPLIT
-----------------------------------------------------------
- Extract the contents of this archive to LiveSplit's Components folder (LiveSplit\Components).
- Open LiveSplit.
- Right-click on the timer area -> Edit Layout.
- Click "+ Add" -> Component.
- Select "SpeedRun Race Tracker" from the list.
- Click OK.

2. REGISTRATION
-----------------------------------------------------------
- Visit the website: https://aut0mat1clol.github.io/SpeedrunRacing
- Create an account (username and password).

3. COMPONENT CONFIGURATION
-----------------------------------------------------------
- In the "Edit Layout" window, right-click on the 
  SpeedRun Race Tracker component -> Edit.
- Enter the username and password you used 
  during registration on the site.
- Click OK.

4. JOINING A RACE
-----------------------------------------------------------
- Get the Race ID from the host or find it on the website.
- Enter the Race ID in the LiveSplit component settings.
- Click "Connect".

Your time will now be transmitted in real-time!
===========================================================
